<?php
/**
 * 
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Appreport
 * @copyright   Copyright (c) 2012 
 * @license     
 */

/**
 * Appreport Helper
 * 
 * @category    
 * @package     Appreport
 * @author      Developer
 */
class Simi_Appreport_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}