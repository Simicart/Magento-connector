<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Connector
 * @copyright   Copyright (c) 2012 
 * @license     
 */

/**
 * Connector Model
 * 
 * @category    
 * @package     Connector
 * @author      Developer
 */
class Simi_Connector_Model_Catalog_Product_Options_Virtual extends Simi_Connector_Model_Catalog_Product_Options_Simple
{

//    public function getOptions($product) {
//        $information = array();
//        return $information;
//    }

}
