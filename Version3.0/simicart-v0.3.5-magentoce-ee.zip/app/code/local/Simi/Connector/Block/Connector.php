<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Connector
 * @copyright   Copyright (c) 2012 
 * @license     
 */

/**
 * Connector Block
 * 
 * @category    
 * @package     Connector
 * @author      Developer
 */
class Simi_Connector_Block_Connector extends Mage_Core_Block_Template {

    /**
     * prepare block's layout
     *
     * @return Simi_Connector_Block_Connector
     */
    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

}