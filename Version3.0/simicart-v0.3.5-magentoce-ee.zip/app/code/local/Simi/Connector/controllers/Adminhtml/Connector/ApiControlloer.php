<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Connector
 * @copyright   Copyright (c) 2012 
 * @license     
 */

/**
 * Api Adminhtml Controller
 * 
 * @category    
 * @package     Connector
 * @author      Developer
 */
class Simi_Connector_Adminhtml_Connector_ApiController extends Mage_Adminhtml_Controller_Action {
    
    public function checkKeyAction(){
        
    }
}