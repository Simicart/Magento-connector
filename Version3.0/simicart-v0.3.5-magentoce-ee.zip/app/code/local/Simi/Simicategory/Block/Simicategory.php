<?php

class Simi_Simicategory_Block_Simicategory extends Mage_Core_Block_Template
{
	public function _prepareLayout(){
		return parent::_prepareLayout();
	}
}