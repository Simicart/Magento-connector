<?php

class Simi_Simicategory_Model_Mysql4_Simicategory extends Mage_Core_Model_Mysql4_Abstract
{
	public function _construct(){
		$this->_init('simicategory/simicategory', 'simicategory_id');
	}
}